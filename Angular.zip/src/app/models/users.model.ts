export class patient {
    id?: Number
    name?: String
    username?: String
    password?: String
}