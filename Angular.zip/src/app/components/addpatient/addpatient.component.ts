import { Component } from '@angular/core';
import { patient } from 'src/app/models/users.model';
import { PatientService } from 'src/app/services/patient.service';

@Component({
  selector: 'app-addpatient',
  templateUrl: './addpatient.component.html',
  styleUrls: ['./addpatient.component.css']
})
export class AddpatientComponent {

  patient: patient = {
    id: NaN,
    name: '',
    username: '',
    password: ''
  };
  submitted = false;

  constructor(private patientService: PatientService) {}

  savePatient(): void {
    const data = {
      id: this.patient.id,
      name: this.patient.name,
      username: this.patient.username,
      password: this.patient.password
    };

    this.patientService.create(data).subscribe({
      next: (res) => {
        console.log(res);
        this.submitted = true;
      },
      error: (e) => console.error(e)
    });
  }

  newPatient(): void {
    this.submitted = false;
    this.patient = {
      id: NaN,
      name: '',
      username: '',
      password: ''
    };
  }

}

