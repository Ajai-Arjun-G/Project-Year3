module.exports = app => {
    const patient = require("../controllers/patient.controller.js")

    var router = require("express").Router()

    router.post("/", patient.create);
    router.get("/:id", patient.findOne);
    router.get("/", patient.findAll)
    router.put("/:id", patient.update);
    router.delete("/:id", patient.delete);
    router.delete("/", patient.deleteAll);
    
    app.use('/patient', router);
}

